# Godot UI 素材包（1920×1080）

## 目录说明

- `assets/reference/`：完整参考图，包含原始 1672×941 与 1920×1080 版本。
- `assets/tiles/`：四块无缝拼接图，可在 Godot 中完整还原画面。
- `assets/panels/`：顶部栏、左侧角色面板、战斗区、底部日志区、属性滚动区。
- `assets/ui/`：货币栏、关卡、设置、头像、技能、装备格、进度条、ACTION、倍速、暂停等独立矩形素材。
- `assets/sprites/source_crops_*`：角色/怪物的原图矩形裁切，像素内容完全保留。
- `assets/sprites/transparent_auto_*`：自动抠出的透明 PNG，便于快速原型验证。
- `assets/hp_bars/`：双方血条素材。
- `scenes/preview_sliced.tscn`：使用四块素材拼回 1920×1080 的默认场景。
- `scenes/preview_fullscreen.tscn`：完整图参考场景。
- `metadata/layout_1920x1080.json`：每张素材的原始与 1920 坐标、尺寸。

## Godot 使用

1. 使用 Godot 4.x 打开本目录的 `project.godot`。
2. 默认启动 `preview_sliced.tscn`，画布为 1920×1080。
3. UI 静态还原优先使用 `assets/tiles/hd_1920/`；需要做交互时，使用 `assets/ui/hd_1920/` 中的按钮和图标。
4. 独立角色原型可使用透明 PNG；正式动画制作建议重新取得分层源文件。

## 清晰度与保真说明

- 原图本身是 1672×941 的扁平 PNG，没有 PSD/分层信息。
- `native_exact` 与 `source_crops_native` 均为原像素直接裁切，没有重绘、调色或内容修改。
- 1920×1080 文件只进行一次高质量 Lanczos 放大，以匹配项目画布；没有改变构图和内容。
- 自动透明抠图属于便利版本，复杂边缘可能带少量背景残留；需要绝对保真时请使用对应的 `source_crops`。
