from __future__ import annotations

import hashlib
import json
import math
import os
import shutil
import textwrap
import zipfile
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

SRC = Path('/mnt/data/萌趣奇幻冒险战斗界面.png')
OUT = Path('/mnt/data/Godot_UI_Asset_Pack_1920x1080')
ZIP = Path('/mnt/data/Godot_UI_Asset_Pack_1920x1080.zip')

NATIVE_W, NATIVE_H = 1672, 941
HD_W, HD_H = 1920, 1080
SX, SY = HD_W / NATIVE_W, HD_H / NATIVE_H

if OUT.exists():
    shutil.rmtree(OUT)
if ZIP.exists():
    ZIP.unlink()

for d in [
    'assets/reference',
    'assets/tiles/native_exact',
    'assets/tiles/hd_1920',
    'assets/panels/native_exact',
    'assets/panels/hd_1920',
    'assets/ui/native_exact',
    'assets/ui/hd_1920',
    'assets/sprites/source_crops_native',
    'assets/sprites/source_crops_hd',
    'assets/sprites/transparent_auto_native',
    'assets/sprites/transparent_auto_hd',
    'assets/hp_bars/native_exact',
    'assets/hp_bars/hd_1920',
    'scenes',
    'metadata',
    'tools',
    'preview',
]:
    (OUT / d).mkdir(parents=True, exist_ok=True)

im_native = Image.open(SRC).convert('RGBA')
assert im_native.size == (NATIVE_W, NATIVE_H), im_native.size
im_hd = im_native.resize((HD_W, HD_H), Image.Resampling.LANCZOS)

# Reference files
im_native.save(OUT / 'assets/reference/full_native_1672x941.png')
im_hd.save(OUT / 'assets/reference/full_hd_1920x1080.png')

# Rects are x1,y1,x2,y2 in native source coordinates.
# Exact partition tiles reconstruct the whole image without gaps or overlap.
TILES = {
    'tile_top_bar': (0, 0, 1672, 100),
    'tile_left_area': (0, 100, 495, 941),
    'tile_battle_area': (495, 100, 1672, 658),
    'tile_bottom_area': (495, 658, 1672, 941),
}

PANELS = {
    'panel_top_bar': (12, 10, 1661, 95),
    'panel_left_character': (24, 98, 489, 900),
    'panel_battle': (500, 103, 1623, 651),
    'panel_bottom_log': (500, 659, 1623, 900),
    'panel_stats_scroll': (55, 532, 470, 838),
}

UI = {
    'currency_gold': (35, 20, 258, 88),
    'currency_purple_gem': (274, 20, 477, 88),
    'currency_blue_crystal': (490, 20, 698, 88),
    'stage_badge': (1246, 22, 1434, 88),
    'settings_button': (1432, 21, 1608, 89),
    'hero_portrait': (59, 112, 217, 278),
    'class_title': (221, 117, 385, 177),
    'skill_class_icon': (234, 179, 332, 278),
    'skill_general_icon': (345, 179, 444, 278),
    'equipment_01_sword': (54, 314, 135, 408),
    'equipment_02_dagger': (136, 314, 219, 408),
    'equipment_03_helmet': (220, 314, 301, 408),
    'equipment_04_armor': (302, 314, 385, 408),
    'equipment_05_glove': (386, 314, 470, 408),
    'equipment_06_boot': (54, 419, 135, 511),
    'equipment_07_green_earring': (136, 419, 219, 511),
    'equipment_08_blue_ring': (220, 419, 301, 511),
    'equipment_09_purple_ring': (302, 419, 385, 511),
    'equipment_10_necklace': (386, 419, 470, 511),
    'battle_progress': (563, 130, 1382, 225),
    'action_button': (1367, 123, 1497, 249),
    'speed_button_x1': (1378, 565, 1486, 642),
    'pause_button': (1490, 565, 1591, 642),
    'bottom_log_title': (846, 672, 1225, 725),
    'bottom_chest_placeholder': (927, 744, 1094, 857),
}

SPRITES = {
    'ally_hero': (548, 331, 792, 571),
    'ally_cat_mage': (772, 329, 984, 568),
    'enemy_mushroom': (1029, 370, 1189, 558),
    'enemy_bat': (1189, 369, 1355, 560),
    'enemy_skeleton': (1347, 349, 1542, 568),
}

HP_BARS = {
    'hp_ally_hero_blue': (604, 319, 706, 346),
    'hp_ally_cat_blue': (793, 326, 904, 355),
    'hp_enemy_mushroom_red': (1047, 363, 1155, 391),
    'hp_enemy_bat_red': (1208, 363, 1318, 391),
    'hp_enemy_skeleton_red': (1374, 363, 1482, 391),
}

# Rough foreground polygons in local crop coordinates for optional auto-masked sprites.
POLYGONS = {
    'ally_hero': [(7,166),(24,148),(43,138),(51,101),(58,70),(79,43),(105,20),(132,12),(158,21),(180,41),(193,69),(188,91),(212,111),(240,133),(242,158),(220,163),(194,154),(177,155),(170,189),(157,225),(126,235),(93,232),(71,219),(61,193),(38,184),(15,182)],
    'ally_cat_mage': [(8,124),(19,90),(34,59),(55,32),(83,12),(112,8),(138,28),(150,53),(157,82),(174,101),(206,91),(210,116),(200,132),(181,145),(173,171),(174,203),(157,227),(130,236),(100,235),(72,223),(50,204),(41,177),(18,164)],
    'enemy_mushroom': [(8,97),(18,75),(39,54),(58,38),(82,28),(107,31),(134,43),(151,64),(157,89),(151,105),(136,116),(137,145),(129,169),(107,183),(78,185),(53,177),(35,160),(29,137),(16,123)],
    'enemy_bat': [(4,106),(17,81),(37,91),(46,65),(58,38),(75,23),(88,34),(98,13),(113,19),(121,42),(138,54),(146,78),(163,72),(160,105),(148,122),(132,116),(124,150),(110,178),(83,184),(59,171),(51,145),(34,126),(15,129)],
    'enemy_skeleton': [(8,132),(20,98),(34,89),(38,60),(55,34),(83,18),(113,19),(140,36),(150,61),(150,83),(165,94),(186,116),(191,148),(181,170),(167,174),(161,194),(143,211),(113,218),(85,214),(66,197),(54,173),(32,170),(13,158)],
}


def scaled_rect(rect):
    x1, y1, x2, y2 = rect
    return (
        int(round(x1 * SX)), int(round(y1 * SY)),
        int(round(x2 * SX)), int(round(y2 * SY)),
    )


def save_crop_set(mapping, native_dir, hd_dir):
    out_meta = {}
    for name, rect in mapping.items():
        n = im_native.crop(rect)
        hrect = scaled_rect(rect)
        h = im_hd.crop(hrect)
        npath = OUT / native_dir / f'{name}.png'
        hpath = OUT / hd_dir / f'{name}.png'
        n.save(npath)
        h.save(hpath)
        out_meta[name] = {
            'native_rect': list(rect),
            'native_size': [n.width, n.height],
            'hd_rect': list(hrect),
            'hd_size': [h.width, h.height],
        }
    return out_meta

metadata = {
    'source': {
        'file': SRC.name,
        'native_size': [NATIVE_W, NATIVE_H],
        'target_size': [HD_W, HD_H],
        'scale_x': SX,
        'scale_y': SY,
        'note': 'HD files are a single proportional Lanczos upscale from the flat source; no redraw, recolor, or layout change.',
    },
}
metadata['tiles'] = save_crop_set(TILES, 'assets/tiles/native_exact', 'assets/tiles/hd_1920')
metadata['panels'] = save_crop_set(PANELS, 'assets/panels/native_exact', 'assets/panels/hd_1920')
metadata['ui'] = save_crop_set(UI, 'assets/ui/native_exact', 'assets/ui/hd_1920')
metadata['sprites_source_crops'] = save_crop_set(SPRITES, 'assets/sprites/source_crops_native', 'assets/sprites/source_crops_hd')
metadata['hp_bars'] = save_crop_set(HP_BARS, 'assets/hp_bars/native_exact', 'assets/hp_bars/hd_1920')

# Generate optional transparent cutouts using polygon-guided GrabCut.
def make_transparent(name, rect, polygon):
    crop = np.array(im_native.crop(rect).convert('RGB'))
    h, w = crop.shape[:2]
    poly = np.array(polygon, dtype=np.int32)
    poly[:, 0] = np.clip(poly[:, 0], 0, w-1)
    poly[:, 1] = np.clip(poly[:, 1], 0, h-1)

    mask = np.full((h, w), cv2.GC_BGD, dtype=np.uint8)
    cv2.fillPoly(mask, [poly], cv2.GC_PR_FGD)
    # Eroded core gives GrabCut a reliable foreground seed.
    poly_mask = np.zeros((h, w), dtype=np.uint8)
    cv2.fillPoly(poly_mask, [poly], 255)
    core = cv2.erode(poly_mask, np.ones((9, 9), np.uint8), iterations=1)
    mask[core > 0] = cv2.GC_FGD

    bgd = np.zeros((1, 65), np.float64)
    fgd = np.zeros((1, 65), np.float64)
    cv2.grabCut(crop, mask, None, bgd, fgd, 5, cv2.GC_INIT_WITH_MASK)
    alpha = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype(np.uint8)

    # Keep meaningful connected components and clean isolated noise.
    num, labels, stats, _ = cv2.connectedComponentsWithStats((alpha > 0).astype(np.uint8), 8)
    clean = np.zeros_like(alpha)
    for i in range(1, num):
        area = stats[i, cv2.CC_STAT_AREA]
        if area >= 30:
            clean[labels == i] = 255
    clean = cv2.morphologyEx(clean, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=1)
    clean = cv2.morphologyEx(clean, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8), iterations=1)

    rgba = np.dstack([crop, clean])
    out_native = Image.fromarray(rgba, 'RGBA')
    out_native.save(OUT / f'assets/sprites/transparent_auto_native/{name}_rgba_auto.png')
    out_hd = out_native.resize((int(round(w * SX)), int(round(h * SY))), Image.Resampling.LANCZOS)
    out_hd.save(OUT / f'assets/sprites/transparent_auto_hd/{name}_rgba_auto.png')

    return {
        'native_size': [w, h],
        'hd_size': [out_hd.width, out_hd.height],
        'method': 'polygon-guided GrabCut; optional convenience asset',
    }

metadata['sprites_transparent_auto'] = {}
for name, rect in SPRITES.items():
    metadata['sprites_transparent_auto'][name] = make_transparent(name, rect, POLYGONS[name])

# Layout JSON
(OUT / 'metadata/layout_1920x1080.json').write_text(
    json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8'
)

# Godot project and scenes.
project_godot = '''; Engine configuration file.
; Generated asset preview project for Godot 4.x
config_version=5

[application]
config/name="Idle RPG UI Asset Pack"
run/main_scene="res://scenes/preview_sliced.tscn"

[display]
window/size/viewport_width=1920
window/size/viewport_height=1080
window/size/window_width_override=1280
window/size/window_height_override=720
window/stretch/mode="canvas_items"

[rendering]
renderer/rendering_method="gl_compatibility"
renderer/rendering_method.mobile="gl_compatibility"
textures/default_filters/use_nearest_mipmap_filter=false
'''
(OUT / 'project.godot').write_text(project_godot, encoding='utf-8')

full_scene = '''[gd_scene load_steps=2 format=3]

[ext_resource type="Texture2D" path="res://assets/reference/full_hd_1920x1080.png" id="1_full"]

[node name="PreviewFullscreen" type="Control"]
layout_mode = 3
anchors_preset = 15
anchor_right = 1.0
anchor_bottom = 1.0
grow_horizontal = 2
grow_vertical = 2

[node name="FullImage" type="TextureRect" parent="."]
layout_mode = 1
anchors_preset = 15
anchor_right = 1.0
anchor_bottom = 1.0
grow_horizontal = 2
grow_vertical = 2
texture = ExtResource("1_full")
expand_mode = 1
stretch_mode = 5
'''
(OUT / 'scenes/preview_fullscreen.tscn').write_text(full_scene, encoding='utf-8')

# Exact tile scene, using HD tiles generated from one upscaled full image.
top_h = scaled_rect(TILES['tile_top_bar'])[3] - scaled_rect(TILES['tile_top_bar'])[1]
left_x = scaled_rect(TILES['tile_left_area'])[2]
right_y = scaled_rect(TILES['tile_battle_area'])[3]

sliced_scene = f'''[gd_scene load_steps=5 format=3]

[ext_resource type="Texture2D" path="res://assets/tiles/hd_1920/tile_top_bar.png" id="1_top"]
[ext_resource type="Texture2D" path="res://assets/tiles/hd_1920/tile_left_area.png" id="2_left"]
[ext_resource type="Texture2D" path="res://assets/tiles/hd_1920/tile_battle_area.png" id="3_battle"]
[ext_resource type="Texture2D" path="res://assets/tiles/hd_1920/tile_bottom_area.png" id="4_bottom"]

[node name="PreviewSliced" type="Control"]
layout_mode = 3
anchors_preset = 15
anchor_right = 1.0
anchor_bottom = 1.0
grow_horizontal = 2
grow_vertical = 2

[node name="TopBar" type="TextureRect" parent="."]
layout_mode = 0
offset_right = 1920.0
offset_bottom = {top_h}.0
texture = ExtResource("1_top")
expand_mode = 1
stretch_mode = 0

[node name="LeftArea" type="TextureRect" parent="."]
layout_mode = 0
offset_top = {top_h}.0
offset_right = {left_x}.0
offset_bottom = 1080.0
texture = ExtResource("2_left")
expand_mode = 1
stretch_mode = 0

[node name="BattleArea" type="TextureRect" parent="."]
layout_mode = 0
offset_left = {left_x}.0
offset_top = {top_h}.0
offset_right = 1920.0
offset_bottom = {right_y}.0
texture = ExtResource("3_battle")
expand_mode = 1
stretch_mode = 0

[node name="BottomArea" type="TextureRect" parent="."]
layout_mode = 0
offset_left = {left_x}.0
offset_top = {right_y}.0
offset_right = 1920.0
offset_bottom = 1080.0
texture = ExtResource("4_bottom")
expand_mode = 1
stretch_mode = 0
'''
(OUT / 'scenes/preview_sliced.tscn').write_text(sliced_scene, encoding='utf-8')

# Copy build script for regeneration/reference.
shutil.copy2(Path(__file__), OUT / 'tools/export_assets.py')

# README
readme = f'''# Godot UI 素材包（1920×1080）

## 目录说明

- `assets/reference/`：完整参考图，包含原始 {NATIVE_W}×{NATIVE_H} 与 1920×1080 版本。
- `assets/tiles/`：四块无缝拼接图，可在 Godot 中完整还原画面。
- `assets/panels/`：顶部栏、左侧角色面板、战斗区、底部日志区、属性滚动区。
- `assets/ui/`：货币栏、关卡、设置、头像、技能、装备格、进度条、ACTION、倍速、暂停等独立矩形素材。
- `assets/sprites/source_crops_*`：角色/怪物的原图矩形裁切，像素内容完全保留。
- `assets/sprites/transparent_auto_*`：自动抠出的透明 PNG，便于快速原型验证。
- `assets/hp_bars/`：双方血条素材。
- `scenes/preview_sliced.tscn`：使用四块素材拼回 1920×1080 的默认场景。
- `scenes/preview_fullscreen.tscn`：完整图参考场景。
- `metadata/layout_1920x1080.json`：每张素材的原始与 1920 坐标、尺寸。

## Godot 使用

1. 使用 Godot 4.x 打开本目录的 `project.godot`。
2. 默认启动 `preview_sliced.tscn`，画布为 1920×1080。
3. UI 静态还原优先使用 `assets/tiles/hd_1920/`；需要做交互时，使用 `assets/ui/hd_1920/` 中的按钮和图标。
4. 独立角色原型可使用透明 PNG；正式动画制作建议重新取得分层源文件。

## 清晰度与保真说明

- 原图本身是 {NATIVE_W}×{NATIVE_H} 的扁平 PNG，没有 PSD/分层信息。
- `native_exact` 与 `source_crops_native` 均为原像素直接裁切，没有重绘、调色或内容修改。
- 1920×1080 文件只进行一次高质量 Lanczos 放大，以匹配项目画布；没有改变构图和内容。
- 自动透明抠图属于便利版本，复杂边缘可能带少量背景残留；需要绝对保真时请使用对应的 `source_crops`。
'''
(OUT / 'README.md').write_text(readme, encoding='utf-8')

# Create an overview image for quick inspection.
thumbs = []
for name in ['panel_top_bar','panel_left_character','panel_battle','panel_bottom_log','panel_stats_scroll']:
    p = OUT / 'assets/panels/hd_1920' / f'{name}.png'
    thumbs.append((name, Image.open(p).convert('RGB')))
for name in ['skill_class_icon','skill_general_icon','speed_button_x1','pause_button']:
    p = OUT / 'assets/ui/hd_1920' / f'{name}.png'
    thumbs.append((name, Image.open(p).convert('RGB')))
for name in SPRITES:
    p = OUT / 'assets/sprites/transparent_auto_hd' / f'{name}_rgba_auto.png'
    # checkerboard composite
    spr = Image.open(p).convert('RGBA')
    bg = Image.new('RGB', spr.size, (210,210,210))
    dr = ImageDraw.Draw(bg)
    s = 16
    for yy in range(0,bg.height,s):
        for xx in range(0,bg.width,s):
            if (xx//s + yy//s)%2:
                dr.rectangle([xx,yy,xx+s-1,yy+s-1], fill=(240,240,240))
    bg.paste(spr, mask=spr.getchannel('A'))
    thumbs.append((name+'_rgba_auto', bg))

canvas = Image.new('RGB', (1600, 1200), (32,32,32))
d = ImageDraw.Draw(canvas)
try:
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 22)
except Exception:
    font = None
x,y = 30,30
row_h = 0
for name, img in thumbs:
    max_w, max_h = 480, 250
    scale = min(max_w/img.width, max_h/img.height, 1.0)
    t = img.resize((max(1,int(img.width*scale)), max(1,int(img.height*scale))), Image.Resampling.LANCZOS)
    if x + t.width > 1570:
        x = 30
        y += row_h + 55
        row_h = 0
    canvas.paste(t, (x,y))
    d.text((x,y+t.height+5), name, fill=(255,255,255), font=font)
    x += t.width + 30
    row_h = max(row_h, t.height)
canvas.crop((0,0,1600,min(1200,y+row_h+60))).save(OUT / 'preview/asset_overview.png')

# Manifest with hashes and sizes.
manifest = []
for p in sorted(OUT.rglob('*')):
    if p.is_file():
        rel = p.relative_to(OUT).as_posix()
        data = p.read_bytes()
        entry = {
            'path': rel,
            'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest(),
        }
        if p.suffix.lower() == '.png':
            with Image.open(p) as ii:
                entry['image_size'] = list(ii.size)
                entry['mode'] = ii.mode
        manifest.append(entry)
(OUT / 'metadata/manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

# Zip package.
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():
            zf.write(p, arcname=f'{OUT.name}/{p.relative_to(OUT).as_posix()}')

print('OUT', OUT)
print('ZIP', ZIP, ZIP.stat().st_size)
print('FILES', len(manifest))
print('TILE_SPLITS_HD', top_h, left_x, right_y)
